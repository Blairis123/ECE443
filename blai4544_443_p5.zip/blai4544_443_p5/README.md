# README #

This README would normally document whatever steps are necessary to get your application up and running.


### What is this repository for? ###

* Demonstrates the sending and receiving of EID messages using CAN1 and CAN2.
* Seem comments for more information.

* Version 1.0

### How do I get set up? ###

* Built on FreeRTOSv202104.00 with limited markup for Tracealyzer and Doxygen.


### Who do I talk to? ###

* Dr. J