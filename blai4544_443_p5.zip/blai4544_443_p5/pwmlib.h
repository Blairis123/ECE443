#define T2_INTR_RATE 10000

// Function prototypes
void pwm_init(int);
void timer2_interrupt_initialize(void);
void pwm_set(int);