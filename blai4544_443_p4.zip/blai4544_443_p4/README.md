# README
### What is this repository for? ###

* To read infrared radiation from an IR sensor and estimate the temprature from that. Then display it on an LCD

* Version 1.0


### How do I get set up? ###

* Built on FreeRTOSv202104.00 with limited markup for Tracealyzer and Doxygen. Only modules with documentation were extracted!



### Who do I talk to? ###

* Owen Blair about the specific project and Dr. J for more accurate details about what the program is actualy supposed to do