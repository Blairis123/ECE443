#include "StepperMotorLib.h"

//Global Variables!
extern unsigned int delay;
extern unsigned int mode;
extern unsigned int direction;
extern unsigned int stepState;
extern int stepTimer;
extern int messageCount;
extern char outputStr[34];     //Used to write to UART



void outputToStepper(unsigned int stepState)
{
    LATBINV = LEDB;
    unsigned int x = stepState;

    x = PORTB;
    x = x & ~SM_COILS;
    x = x | (stepState<<7);
    LATB = x;
}

/*
 stepperStatemachine function description:
 *  This function takes the current state of the stepper and the direction
 *  that the stepper motor needs to move in.
 */
unsigned int stepperStateMachine(unsigned int direction, unsigned int stepState, unsigned int mode)
{
    switch(stepState)
    {
        case s0_5:
            if (direction == CW)
            {
                if(mode == FS)
                {
                    stepState = s1_5;
                }
                else
                {
                    stepState = s1;
                }
            }
            else    //CCW
            {
                if(mode == FS)
                {
                    stepState = s3_5;
                }
                else
                {
                    stepState = s4;
                }
            }
            break;

        case s1:
            if (direction == CW)
            {
                if(mode == FS)
                {
                    stepState = s2;
                }
                else
                {
                    stepState = s1_5;
                }
            }
            else    //CCW
            {
                if(mode = FS)
                {
                    stepState = s4;
                }
                else
                {
                    stepState = s0_5;
                }
            }
            break;
        
        case s1_5:
            if (direction == CW)
            {
                if(mode ==FS)
                {
                    stepState = s2_5;
                }
                else
                {
                    stepState = s2;
                }
            }
            else    //CCW
            {
                if(mode == FS)
                {
                    stepState = s0_5;
                }
                else
                {
                    stepState = s1;
                }
            }
            break;
            
        case s2:
            if (direction == CW)
            {
                if(mode == FS)
                {
                    stepState = s3;
                }
                else
                {
                    stepState = s2_5;
                }
            }
            else    //CCW
            {
                if(mode == FS)
                {
                    stepState = s1;
                }
                else
                {
                    stepState = s1_5;
                }
            }
            break;
            
        case s2_5:
            if (direction == CW)
            {
                if(mode == FS)
                {
                    stepState = s3_5;
                }
                else
                {
                    stepState = s3;
                }
            }
            else    //CCW
            {
                if(mode == FS)
                {
                    stepState = s1_5;
                }
                else
                {
                    stepState = s2;
                }
            }
            break;
            
        case s3:
            if (direction == CW)
            {
                if(mode == FS)
                {
                    stepState = s4;
                }
                else
                {
                    stepState = s3_5;
                }
            }
            else    //CCW
            {
                if(mode == FS)
                {
                    stepState = s2;
                }
                else
                {
                    stepState = s2_5;
                }
            }
            break;
            
        case s3_5:
            if (direction == CW)
            {
                if(mode == FS)
                {
                    stepState = s0_5;
                }
                else
                {
                    stepState = s4;
                }
            }
            else    //CCW
            {
                if(mode == FS)
                {
                    stepState = s2_5;
                }
                else
                {
                    stepState = s3;
                }
            }
            break;
            
        case s4:
            if (direction == CW)
            {
                if(mode == FS)
                {
                    stepState = s1;
                }
                else
                {
                    stepState = s0_5;
                }
            }
            else    //CCW
            {
                if(mode == FS)
                {
                    stepState = s3;
                }
                else
                {
                    stepState = s3_5;
                }
            }
            break;
    return stepState;
    }
}

// The following is unused due to the use of FreeRTOS & its ability to schedule!
/*
void timer1_interrupt_initialize(void)
{
    //configure Timer 1 with internal clock, 1:1 prescale, PR1 for 1 ms period
    OpenTimer1(T1_ON | T1_SOURCE_INT | T1_PS_1_1, T1_INTR_RATE-1);
    // set up the timer interrupt with a priority of 2, sub priority 0
    mT1SetIntPriority(1); // Group priority range: 1 to 7
    mT1SetIntSubPriority(0); // Subgroup priority range: 0 to 3
    mT1IntEnable(1); // Enable T1 interrupts
    // Global interrupts must enabled to complete the initialization.
}

//T1 ISR!
void __ISR(_TIMER_1_VECTOR, IPL2) Timer1Handler(void)
{
    stepTimer--;
    if(stepTimer <= 0)
    {
        stepState = stepperStateMachine(direction, stepState, mode);
        outputToStepper(stepState);
        
        stepTimer = delay;//If buttons don't change keep at same speed (delay)
    }
    LATBINV = LEDA; //toggle LED A
    mT1ClearIntFlag();
}
*/
