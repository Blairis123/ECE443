#include "ButtonLib.h"

//Global Variables!
extern unsigned int delay;
extern unsigned int mode;
extern unsigned int direction;
extern unsigned int stepState;
extern int stepTimer;
extern int messageCount;
extern char outputStr[34];     //Used to write to TCP

enum StepState{s0_5 = 0x0A, s1 = 0x08, s1_5 = 0x09, s2 = 0x01, s2_5 = 0x05, s3 = 0x04, s3_5 = 0x06, s4 = 0x02};
enum Direction{CW = 1, CCW = 2};
enum Mode{FS = 1, HS = 2};

/* decode_buttons Function Description ***************************************
 * NOTES:           Refer to Cerebot MX7cK data sheet for button bit positions
 *             The delay determines the speed at which the stepper motor
 *              rotates at! This information is decoded from user input within
 *              this function.
 * 
 *  CHANGED FROM LAB 4!! Got rid of pointers because using global vars
 * END DESCRIPTION ***********************************************************/
void decode_buttons(unsigned int buttons, unsigned int *delay, unsigned int *mode, unsigned int *direction)
{
    char OutputStr[34] = "";  //Used to write to LCD
    char dirStr[4] = "";         //Used to track direction
    char modeStr[5] = "";        //Used to track mode
    int speed =0;
    switch(buttons)
    {
        case 0://All of
            *direction = CW;
            *mode = HS;
            *delay = 20;
            strcpy(dirStr, "CW");
            strcpy(modeStr, "HALF");
            speed = 15;
            break;
            
        case 1://BTN1 on, BTN2 off
            *direction = CW;
            *mode = FS;
            *delay = 40;
            strcpy(dirStr, "CW");
            strcpy(modeStr, "FULL");
            speed = 15;
            break;
            
        case 2://BTN1 off, BTN2 on
            *direction = CCW;
            *mode = HS;
            *delay = 30;
            strcpy(dirStr, "CCW");
            strcpy(modeStr, "HALF");
            speed = 10;
            break;
            
        case 3://BTN1 on, BTN on
            *direction = CCW;
            *mode = FS;
            *delay = 24;
            strcpy(dirStr, "CCW");
            strcpy(modeStr, "FULL");
            speed = 25;
            break;    
    }
    
    
    mCNIntEnable(0); //Write to LCD
    sprintf(OutputStr, "%s %s %d RPM", dirStr, modeStr, speed);
    strcpy(outputStr, OutputStr);// Copy to global value so it can be sent via TCP
    writeLCD(0, 0x01);
    LCD_puts(OutputStr);
    
    //sprintf(OutputStr, "%s %s %d RPM : Set by operator", dirStr, modeStr, speed);
    //putsU1(OutputStr);
    mCNIntEnable(1); //Turn interrupts back on
}

/* Initialization of CN peripheral for interrupt level 1 */
void cn_interrupt_initialize(void) // Code that is executed only once
{
    unsigned int dummy; // used to hold PORT read value

    // Enable CN for BTN1 and BTN2
    mCNOpen(CN_ON,(CN8_ENABLE | CN9_ENABLE), 0);
    
    // Set CN interrupts priority level 1 sub priority level 0
    mCNSetIntPriority(1); // Group priority (1 to 7)
    mCNSetIntSubPriority(0); // Subgroup priority (0 to 3)
    
    // read port to clear difference
    dummy = PORTReadBits(IOPORT_G, BTN1 | BTN2);
    
    mCNClearIntFlag(); // Clear CN interrupt flag
    mCNIntEnable(1); // Enable CN interrupts
    // Global interrupts must enabled to complete the initialization.
}

/* read_buttons Function Description *****************************************
 * SYNTAX:          int read_buttons(void);
 * KEYWORDS:        button, read, inputs
 * DESCRIPTION:     Reads the status of the input buttons.  Button status is
 *                  reported for button bit positions only. All other bits in
 *                  the returned value are set to zero as shown below:
 *
 *      Port G Bit position [15|14|13|12|11|10| 9| 8| 7| 6| 5| 4| 3| 2| 1| 0]
 *      Port G Bit value    [ 0| 0| 0| 0| 0| 0| 0| 0|B2|B1| 0| 0| 0| 0| 0| 0]
 *
 *      B1 will be 1 if BTN1 is pressed otherwise B1 will be zero
 *      B2 will be 1 if BTN2 is pressed otherwise B2 will be zero
 * END DESCRIPTION ************************************************************/
int read_buttons(void)
{
    unsigned int x = 0;
    x = PORTReadBits(IOPORT_G, BTN1 | BTN2);
    x = x >> 6; //Shift bits over so the return value will be 0,1,2, or 3
    return x;
}

/*hw_msDelay Function Description ******************************************
* SYNTAX:         void hw_msDelay(unsigned int mS);
* DESCRIPTION: This is a millisecond delay function uses the core time
*   to set the base millisecond delay period. Delay periods
*   of zero are permitted. LEDA is toggled each millisecond.
* KEYWORDS:  delay, ms, milliseconds, software delay, core timer
* PARAMETER1: mS - the total number of milliseconds to delay
* RETURN VALUE: None:
* END DESCRIPTION *********************************************************/
void hw_msDelay(unsigned int mS)
{
    unsigned int tWait, tStart;
    tStart = ReadCoreTimer();   //Read core timer count -- SW breakpoint
    tWait = (CORE_MS_TICK_RATE * mS);    //Time to wait
    while((ReadCoreTimer() - tStart) < tWait);  //Empty loop, whit for time
}

void __ISR(_CHANGE_NOTICE_VECTOR, IPL1) CNIntHandler(void)
{
    LATBINV = LEDC;
    hw_msDelay(20);
    int btnInput = read_buttons();  //Read and assign value for later use
    
    decode_buttons(btnInput, &delay, &mode, &direction);
    
    /* Required to clear the interrupt flag in the ISR */
    mCNClearIntFlag(); // Macro function
    LATBINV = LEDC;
}