# README #


### What is this repository for? ###

* Creates a TCP socket for sending Core Timer
*
* v1.0 31Oct2022

### How do I get set up? ###

* Download FreeRTOSv202104.00.zip from 443 handouts
* Unzip and place clone this repo under the Projects folder
* IP address is set using define in main.c as sourceAddress
* Also defines port 10000 as the listeningPor

### Who do I talk to? ###

* Dr. J - aka The Man
