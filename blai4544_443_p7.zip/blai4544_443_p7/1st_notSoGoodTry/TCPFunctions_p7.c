/* ************************************************************************** */
/** Descriptive File Name

  @Company
    Company Name

  @File Name
    filename.c

  @Summary
    Brief description of the file.

  @Description
    Describe the purpose of this file.
 */


/* vCreateTCPServerSocket Function Description *************************
 * SYNTAX:          static void vCreateTCPServerSocket( void *pvParameters );
 * KEYWORDS:        RTOS, Task
 * DESCRIPTION:     Waits for an incoming request for a TCP socket connection 
 *                  to be made. The function then, launches a new task for 
 *                  managing the connection and deletes itself.
 * PARAMETER 1:     void pointer - data of unspecified data type sent from
 *                  RTOS scheduler
 * RETURN VALUE:    None (There is no returning from this function)
END DESCRIPTION ************************************************************/
static void vCreateTCPServerSocket( void *pvParameters )
{
    struct freertos_sockaddr xClient, xBindAddress;
    Socket_t xListeningSocket, xConnectedSocket;
    socklen_t xSize = sizeof( xClient );
    static const TickType_t xReceiveTimeOut = portMAX_DELAY;
    const BaseType_t xBacklog = 20;
    BaseType_t xReturned;

    /* Attempt to open the socket. */
    xListeningSocket = FreeRTOS_socket( FREERTOS_AF_INET,
					FREERTOS_SOCK_STREAM,/* FREERTOS_SOCK_STREAM for TCP. */
					FREERTOS_IPPROTO_TCP );

    /* Check the socket was created. */
    configASSERT( xListeningSocket != FREERTOS_INVALID_SOCKET );

    /* Set a time out so accept() will just wait for a connection. */
    FreeRTOS_setsockopt( xListeningSocket,
                         0,
                         FREERTOS_SO_RCVTIMEO,
                         &xReceiveTimeOut,
                         sizeof( xReceiveTimeOut ) );

    /* Set the listening port. */
    xBindAddress.sin_port = ( uint16_t ) listeningPort;
    xBindAddress.sin_port = FreeRTOS_htons( xBindAddress.sin_port );

    /* Bind the socket to the port that the client RTOS task will send to. */
    FreeRTOS_bind( xListeningSocket, &xBindAddress, sizeof( xBindAddress ) );

    /* Set the socket into a listening state so it can accept connections.
    The maximum number of simultaneous connections is limited to 20. */
    FreeRTOS_listen( xListeningSocket, xBacklog );

    for( ;; )
    {
        /* Wait for incoming connections. */
        xConnectedSocket = FreeRTOS_accept( xListeningSocket, &xClient, &xSize );
        configASSERT( xConnectedSocket != FREERTOS_INVALID_SOCKET );

        /* Spawn a RTOS task to handle the connection. */
        xReturned = xTaskCreate( prvServerConnectionInstance,
                     "TimerRpt",
                     512, /* I've increased the memory allocated to the task as I was encountering stack overflow issues */
                     ( void * ) xConnectedSocket,
                     tskIDLE_PRIORITY,
                     NULL );
        
        if (xReturned == pdPASS)
            vTaskDelete( NULL );
        
        while(1);
    } // for(;;)
} // vCreateTCPServerSocket


/* prvServerConnectionInstance Function Description *************************
 * SYNTAX:          static void prvServerConnectionInstance( void *pvParameters );
 * KEYWORDS:        RTOS, Task
 * DESCRIPTION:     Periodically sends the core timer
 * PARAMETER 1:     void pointer - data of unspecified data type sent from
 *                  RTOS scheduler
 * RETURN VALUE:    None (There is no returning from this function)
END DESCRIPTION ************************************************************/
static void prvServerConnectionInstance( void *pvParameters )
{
	int32_t lBytes, lSent, lTotalSent;
	uint8_t cReceivedString[ ipconfigTCP_MSS ];
	Socket_t xConnectedSocket;
	static const TickType_t xReceiveTimeOut = pdMS_TO_TICKS( 5000 );
	static const TickType_t xSendTimeOut = pdMS_TO_TICKS( 5000 );
	TickType_t xTimeOnShutdown;

	xConnectedSocket = ( Socket_t ) pvParameters;
	FreeRTOS_setsockopt( xConnectedSocket, 0, FREERTOS_SO_RCVTIMEO, &xReceiveTimeOut, sizeof( xReceiveTimeOut ) );
	FreeRTOS_setsockopt( xConnectedSocket, 0, FREERTOS_SO_SNDTIMEO, &xSendTimeOut, sizeof( xReceiveTimeOut ) );

	for( ;; )
	{
		vTaskDelay(500/portTICK_PERIOD_MS);
                
        /* Zero out the receive array so there is NULL at the end of the string
		 * when it is printed out. */
		memset( cReceivedString, 0x00, sizeof( cReceivedString ) );
                
                sprintf (cReceivedString, "Insert CMD response here (port 10000)\r\n");
                lBytes = strlen(cReceivedString) + 1; // include NULL

		/* If Send the string. */
		if( lBytes >= 0 )
		{
		    lSent = 0;
		    lTotalSent = 0;
			
			while( ( lSent >= 0 ) && ( lTotalSent < lBytes ) )
			{
				lSent = FreeRTOS_send( xConnectedSocket, &cReceivedString[lTotalSent], lBytes - lTotalSent, 0 );
				lTotalSent += lSent;
			}

			if( lSent < 0 )
			{
				/* Socket closed? */
				break;
			}
		} // if
		else // lBytes < 0
		{
			/* Socket closed? */
			break;
		}
	} // for(;;)
	
	/* Initiate a shutdown in case it has not already been initiated. */
	FreeRTOS_shutdown( xConnectedSocket, FREERTOS_SHUT_RDWR );

	/* Wait for the shutdown to take effect, indicated by FreeRTOS_recv()
	 * returning an error. */
	xTimeOnShutdown = xTaskGetTickCount();
	do
	{
	    if( FreeRTOS_recv( xConnectedSocket, cReceivedString, ipconfigTCP_MSS, 0 ) < 0 )
	    {
		    break;
	    }
	} while( ( xTaskGetTickCount() - xTimeOnShutdown ) < tcpechoSHUTDOWN_DELAY );

	/* Finished with the socket and the task. */
	FreeRTOS_closesocket( xConnectedSocket );
	vTaskDelete( NULL );
} // prvServerConnectionInstance


/* *****************************************************************************
 End of File
 */
