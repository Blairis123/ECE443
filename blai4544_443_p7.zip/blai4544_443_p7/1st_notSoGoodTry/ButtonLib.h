#include <plib.h>
#include "CerebotMX7cK.h"




int read_buttons(void);
void decode_buttons(unsigned int, unsigned int *, unsigned int *, unsigned int *);
void cn_interrupt_initialize(void);
void hw_msDelay(unsigned int);