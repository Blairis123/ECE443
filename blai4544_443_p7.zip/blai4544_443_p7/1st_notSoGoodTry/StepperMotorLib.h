#include <plib.h>
#include "CerebotMX7cK.h"


//Enum definitions for stepper!
extern enum StepState{s0_5 = 0x0A, s1 = 0x08, s1_5 = 0x09, s2 = 0x01, s2_5 = 0x05, s3 = 0x04, s3_5 = 0x06, s4 = 0x02};
extern enum Direction{CW = 1, CCW = 2};
extern enum Mode{FS = 1, HS = 2};


#define T1_INTR_RATE 10000 // For 1 ms interrupt rate with T1 clock=10E6

/* Function prototypes */
void outputToStepper(unsigned int stepState);
unsigned int stepperStateMachine(unsigned int direction, unsigned int stepState, unsigned int mode);
void timer1_interrupt_initialize(void);
