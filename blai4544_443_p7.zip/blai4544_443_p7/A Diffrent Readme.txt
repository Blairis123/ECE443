The following has been completed upon onedrive submission
	Move stepper motor - Set up tasks to reassign stepper state every delay cycle
	Send stepper motor data every 500ms

The follwoing has yet to be completed upon onedrive submission
	Give stepper motor commands via Putty + TCP