# README #

This README would normally document whatever steps are necessary to get your application up and running.

### What is this repository for? ###

* Creates two tasks which alternate lighting LEDA or LEDB.

* Version 1.0

### How do I get set up? ###

* Built on FreeRTOSv202104.00 with limited markup for Tracealyzer and Doxygen.


### Who do I talk to? ###

* Dr. J