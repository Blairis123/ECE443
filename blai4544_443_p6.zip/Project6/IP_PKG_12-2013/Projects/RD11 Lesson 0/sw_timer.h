/* 	sw_timer.h - Software time include file
**
** Author:  Richard Wall
** Date:    September 30, 2011
** 
** Revised: November 2, 2014 - R. Wall, Added PeriodMS - a non blocking delay
**
**
*/
#ifndef __SW_TIMER_H__
    #define __SW_TIMER_H__
    #include <plib.h>

/* core timer constants */
    #define TOGGLES_PER_MSEC	1000   			//for milliseconds
    #define CORE_TICKS_PER_MS	(GetSystemClock()/2/TOGGLES_PER_MSEC)

#endif

// Function prototypes
void DelayMs(unsigned int msec);
void DelayUs(unsigned int us);
int PeriodMs(unsigned int msec);

/* End of swe_timer.h */
